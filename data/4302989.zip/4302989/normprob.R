normprob <- function(lo, hi, mu, sigma) {
  
  pnorm(hi, mean = mu  ,sd = sigma) - pnorm (lo, mean = mu , sd = sigma )
}
