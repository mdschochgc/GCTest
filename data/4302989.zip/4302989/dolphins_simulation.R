 diff <- rep(NA,500)
 for (i in 1:500)  {
     result <- prop.table(table(dolphins$Improve, sample (dolphins$Treatment)), margin = 2 )
     diff[i] = result[2,2] - result [2,1]
 }
 hist(diff)